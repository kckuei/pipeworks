# PipeWorks
A collection of generic classes for computing pressurized and open channel hydraulics for outlet works.

Currently, setup for pressurized or unpressurized circular pipe flow.

## Installation
To install the [package](https://pypi.org/project/pipeworks/0.0.1/) via CLI:

Using pip:
```
pip install pipeworks==0.0.1
```

Using conda:
```
conda install ..
```

## Examples


