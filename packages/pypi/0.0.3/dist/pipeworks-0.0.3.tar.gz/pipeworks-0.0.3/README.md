# PipeWorks
A collection of classes and functions for computing pressurized and open channel hydraulics for outlet works.

